19.1. DISTINCT. Выборка уникальных значений:
SELECT DISTINCT Manufacturer FROM Products



19.2. ORDER BY.  Сортировка:
SELECT * FROM Products
ORDER BY ProductCount



SELECT ProductName, ProductCount * Price AS TotalSum
FROM Products
ORDER BY TotalSum



SELECT ProductName, Price, ProductCount
FROM Products
ORDER BY ProductCount * Price



19.3. Сортировка по убыванию:
SELECT ProductName, Manufacturer
FROM Products
ORDER BY Manufacturer DESC



19.4. Сортировка по возрастанию:
SELECT ProductName, Manufacturer
FROM Products
ORDER BY Manufacturer ASC



19.5. Сортировка по нескольким столбцам
SELECT ProductName, Price, Manufacturer
FROM Products
ORDER BY Manufacturer, ProductName



SELECT ProductName, Price, Manufacturer
FROM Products
ORDER BY Manufacturer ASC, ProductName DESC