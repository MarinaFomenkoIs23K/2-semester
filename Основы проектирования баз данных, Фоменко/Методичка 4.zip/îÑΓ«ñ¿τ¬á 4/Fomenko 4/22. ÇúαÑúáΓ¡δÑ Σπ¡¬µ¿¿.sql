22.1. AVG:
SELECT AVG(Price) AS Average_Price FROM Products



SELECT AVG(Price) FROM Products
WHERE Company = 'Apple'



SELECT AVG(Price * ProductCount) FROM Products



22.2. COUNT:
SELECT COUNT(*) FROM Products



SELECT COUNT(DISTINCT Company) FROM Products



22.3. MIN и MAX:
SELECT MIN(Price) FROM Products



SELECT MAX(Price) FROM Products



22.4. SUM:
SELECT SUN(ProductCount) FROM Products



SELECT SUM(ProductCount * Price) FROM Products



22.5. BOOL_AND и BOOL_OR:
SELECT BOOL_OR(IsDiscounted) FROM Products



SELECT BOOL_AND(isDiscounted) FROM Products



22.6. STRING_AGG:
SELECT STRING_AGG(ProductName, ',') FROM Products



SELECT STRING_AGG(DISTINCT Company, ',' FROM Products



22.7. Комбинирование функций:
SELECT COUNT(*) AS ProdCount,
    SUM(ProductCount) AS TotalCount,
    MIN(Price) AS MinPrice,
    MAX(Price) AS MaxPrice,
    AVG(Price) AS AvgPrice
FROM Products