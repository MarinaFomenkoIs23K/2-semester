11.1. Добавление нового столбца:
ALTER TABLE Customers
ADD Phone CHARACTER VARYING(20) NULL



11.2. Удаление столбца:
ALTER TABLE Customers
DROP COLUMN Address



11.3. Изменение типа столбца:
ALTER TABLE Customers
ALTER COLUMN FirstName TYPE VARCHAR(50)



11.4. Изменение ограничений столбца:
ALTER TABLE Customers
ALTER COLUMN FirstName
SET NOT NULL



11.5. Переименование таблицы:
ALTER TABLE Customers
RENAME TO Users