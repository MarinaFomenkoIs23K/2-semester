SELECT * FROM Products
ORDER BY ProductName
LIMIT 4



SELECT * FROM Products
ORDER BY ProductName
LIMIT 3 OFFSET 2



SELECT * FROM Products
ORDER BY ProductName
LIMIT ALL OFFSET 2