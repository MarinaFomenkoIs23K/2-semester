24.1. HAVING:
SELECT Company, COUNT(*) AS ModelsCount
FROM Products
GROUP BY Company
HAVING COUNT(*) > 1



SELECT Company, COUNT(*) AS ModelsCount
FROM Products
WHERE Price * ProductCount > 80000
GROUP BY Company
HAVING COUNT(*) > 1



24.2. GROUPING SETS, CUBE и ROLLUP:
SELECT Company, COUNT(*) AS Models, ProductCount
FROM Products
GROUP BY GROUPING SETS(Company, ProductCount)



SELECT Company, COUNT(*) AS Models, SUM(ProductCount) AS Units
FROM Products
GROUP BY ROLLUP(Company)



SELECT Company, COUNT(*) AS Models, SUM(ProductCount) AS Units
FROM Products
GROUP BY ROLLUP(Company, ProductCount)
ORDER BY Company



SELECT Company, COUNT(*) AS Models, SUM(ProductCount) AS Units
FROM Products
GROUP BY CUBE(Company, ProductCount)