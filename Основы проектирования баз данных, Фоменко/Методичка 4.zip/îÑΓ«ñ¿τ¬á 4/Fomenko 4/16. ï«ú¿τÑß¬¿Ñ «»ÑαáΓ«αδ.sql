SELECT * FROM Products
WHERE Manufacturer = 'Samsung' OR Price > 50000