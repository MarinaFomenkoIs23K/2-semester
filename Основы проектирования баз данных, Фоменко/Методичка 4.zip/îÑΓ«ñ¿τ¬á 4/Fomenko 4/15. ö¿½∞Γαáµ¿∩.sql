SELECT * FROM Products
WHERE Manufacturer = 'Apple'



SELECT * FROM Products
WHERE Price * ProductCount > 90000