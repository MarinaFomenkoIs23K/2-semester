DELETE FROM Products
WHERE Manufacturer = 'Apple';

SELECT * FROM Products