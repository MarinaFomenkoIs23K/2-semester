SELECT * FROM Orders, Customers



SELECT * FROM Orders, Customers
WHERE Orders.CustomerId = Customers.Id



SELECT Customers.FirstName, Products.ProductName, Orders.CreateAt
FROM Orders, Customers, Products
WHERE Orders.CustomerId = Customers.Id AND Orders.ProductId=Products.Id