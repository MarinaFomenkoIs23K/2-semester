SELECT * FROM Products



SELECT ProductName, Price FROM Products