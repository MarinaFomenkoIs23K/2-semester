SELECT *
FROM Products
WHERE Price = (SELECT MIN(Price) FROM Products)



SELECT *
FROM Products
WHERE Price > (SELECT AVG(Price) FROM Products)