21.1. Оператор IN:
SELECT * FROM Products
WHERE Manufacturer IN ('Samsung', 'HTC', 'Huawei')



SELECT * FROM Products
WHERE Manufacturer NOT IN ('Samsung', 'HTC', 'Huawei')



21.2. Оператор BETWEEN:
SELECT * FROM Products
WHERE Price BETWEEN 20000 AND 50000



SELECT * FROM Products
WHERE Price NOT BETWEEN 20000 AND 50000



21.3. Оператор LIKE:
SELECT * FROM Products
WHERE ProductName LIKE 'iPhone%'