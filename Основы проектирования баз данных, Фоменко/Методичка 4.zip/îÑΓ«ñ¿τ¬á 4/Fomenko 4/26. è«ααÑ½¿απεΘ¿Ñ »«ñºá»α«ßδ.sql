SELECT CreatedAt,
    Price,
    (SELECT ProductName FROM Products
    WHERE Products.Id = Orders.ProductId) AS Product
FROM Orders



SELECT ProductName,
    Company,
    Price,
    (SELECT AVG(Price) FROM Products AS SubProds
    WHERE SubProds.Company=Prods.Company) AS AvgPrice
FROM Products AS Prods
WHERE Price >
    (SELECT AVG(Price) FROM Products AS SubProds
    WHERE SubProds.Company=Prods.Company)