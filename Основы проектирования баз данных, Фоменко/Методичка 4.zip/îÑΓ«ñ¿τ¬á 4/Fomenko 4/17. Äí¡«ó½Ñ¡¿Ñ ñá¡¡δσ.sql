UPDATE Products
SET Price = Price + 3000;

SELECT * FROM Products