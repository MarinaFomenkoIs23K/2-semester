select tags[1:3] from posts



update posts
set tags='{}'
where id=1



update posts
set tags='{"sql", "postgres", "database"}'
where id=1



update posts
set tags[2]='system'
where id=1;
select tags from posts