def count_syllables_in_words():
    M = int(input("Введите количество строк: "))
    words = []
    for i in range(M):
        word = input(f"Введите слово {i + 1}: ")
        words.append(word)
    syllable = input("Введите слог для поиска: ")
    for i, word in enumerate(words):
        count = word.count(syllable)
        print(f"Слог '{syllable}' встречается в слове '{word}': {count} раз(а)")
count_syllables_in_words()
